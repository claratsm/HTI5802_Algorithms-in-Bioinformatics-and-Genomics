library("qqman", lib.loc="../R/el8-x86_64-singularity-library/4.2")

args <- commandArgs(trailingOnly = TRUE)

assoc <- read.table(args[1], header=T)

png(paste(args[2],".png",sep=""), width=720, height=400)
manhattan(assoc, suggestiveline=F)
dev.off()
