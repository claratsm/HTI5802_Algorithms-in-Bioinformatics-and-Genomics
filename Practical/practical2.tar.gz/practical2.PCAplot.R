#library(RColorBrewer)
args = commandArgs(trailingOnly=TRUE)

pcafile <- args[1]

pop.AFR <- c("ACB","ASW","ESN","GWD","LWK","MSL","YRI")
pop.AMR <- c("CLM","MXL","PEL","PUR")
pop.EUR <- c("CEU","FIN","GBR","IBS","TSI")
pop.SAS <- c("BEB","GIH","ITU","PJL","STU")
pop.EAS <- c("CDX","CHB","CHS","JPT","KHV","ASA")
pop.all <- c(pop.AFR,pop.AMR,pop.EUR,pop.SAS,pop.EAS)
index.pop <- order(pop.all)

#col.AFR <- brewer.pal(length(pop.AFR),"Blues")
#col.AMR <- brewer.pal(length(pop.AMR),"RdPu")
#col.EUR <- brewer.pal(length(pop.EUR),"Greens") 
#col.SAS <- brewer.pal(length(pop.SAS),"YlOrBr") 
#col.EAS <- brewer.pal(length(pop.EAS),"YlOrRd")
#col.all <- c(col.AFR,col.AMR,col.EUR,col.SAS,col.EAS)
#col.pop <- col.all[index.pop]
col.all <- c("#EFF3FF","#C6DBEF","#9ECAE1","#6BAED6","#4292C6","#2171B5","#084594","#FEEBE2","#FBB4B9","#F768A1","#AE017E","#EDF8E9","#BAE4B3","#74C476","#31A354","#006D2C","#FFFFD4","#FED98E","#FE9929","#D95F0E","#993404","#FFFFB2","#FED976","#FEB24C","#FD8D3C","#F03B20","black")
col.pop <- c("#EFF3FF","black","#C6DBEF","#FFFFD4","#FFFFB2","#EDF8E9","#FED976","#FEB24C","#FEEBE2","#9ECAE1","#BAE4B3","#74C476","#FED98E","#6BAED6","#31A354","#FE9929","#FD8D3C","#F03B20","#4292C6","#2171B5","#FBB4B9","#F768A1","#D95F0E","#AE017E","#993404","#006D2C","#084594")
#=============
# All 1000G
#=============
pca<-read.table(pcafile)
sample.1kg<-read.table("integrated_call_samples_v3.20130502.ALL.panel",h=T,stringsAsFactors=FALSE)

pca.1kg<-merge(pca[,2:5],sample.1kg,by.x="V2",by.y="sample",all.x=T)
colnames(pca.1kg) <- c("IID",paste("PC",1:3,sep=""),colnames(pca.1kg)[5:ncol(pca.1kg)])

pca.1kg$super_pop[is.na(pca.1kg$super_pop)] <- "EAS"
pca.1kg$pop[is.na(pca.1kg$pop)] <- "ASA"
pca.1kg$colpop <- as.integer(factor(pca.1kg$pop))

png("practical2.1000G-all.PCA.png", width=720,height=720,res=300,pointsize=5)
par(mar=c(5,4.5,5,5.5),xpd=T)
plot(pca.1kg$PC1,pca.1kg$PC2,pch=16,col=col.pop[pca.1kg$colpop],xlab="Principal component 1",ylab="Principal component 2",lwd=.6,cex=.6,font.lab=2)
points(pca.1kg$PC1[pca.1kg$pop=="ASA"],pca.1kg$PC2[pca.1kg$pop=="ASA"],pch=21,bg="grey",col="black",cex=.8)

legend("topright", inset=c(-0.25,0), legend=pop.all, pch=c(rep(16,26),21), col=col.all, pt.bg=c(col.all[1:26],"grey"), cex=.8)
dev.off()
